-- TABLE
CREATE TABLE demo (ID integer primary key, Name varchar(20), Hint text );
CREATE TABLE jogos_esportivos(
  
  esporte varchar(100) not null,
  equipe_casa varchar(100) not null,
  equipe_visitante varchar(100) not null,
  pontuacao_casa int,
  pontuacao_visitante int,
  data_jogo date
  );
 
-- INDEX
 
-- TRIGGER
 
-- VIEW
 
